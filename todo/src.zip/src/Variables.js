export const variables={
    API_URL:"https://localhost:44315/api/",
}